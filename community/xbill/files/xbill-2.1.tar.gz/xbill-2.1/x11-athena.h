#ifndef X11_ATHENA_H
#define X11_ATHENA_H

#include "UI.h"

void
x11_athena_setmethods(UI_methods **methodsp);

#endif
