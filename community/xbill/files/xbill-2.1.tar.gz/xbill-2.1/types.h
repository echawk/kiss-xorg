#ifndef TYPES_H
#define TYPES_H

typedef struct Scorelist Scorelist;
typedef struct Picture Picture;
typedef struct MCursor MCursor;
typedef struct Cable Cable;
typedef struct Bill Bill;
typedef struct Computer Computer;

#endif
