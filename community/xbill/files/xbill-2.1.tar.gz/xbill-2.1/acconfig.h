/* Use athena widgets */
#undef USE_ATHENA

/* Use motif widgets */
#undef USE_MOTIF

/* Use gtk widgets */
#undef USE_GTK
