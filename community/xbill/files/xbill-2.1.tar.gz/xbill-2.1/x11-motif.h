#ifndef X11_MOTIF_H
#define X11_MOTIF_H

#include "UI.h"

void
x11_motif_setmethods(UI_methods **methodsp);

#endif
