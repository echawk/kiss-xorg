#ifndef GTK_H
#define GTK_H

#include "UI.h"

void
gtk_ui_setmethods(UI_methods **methodsp);

#endif
